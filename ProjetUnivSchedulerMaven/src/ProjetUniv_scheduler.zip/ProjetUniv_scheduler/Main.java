package ProjetUniv_scheduler;

public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}